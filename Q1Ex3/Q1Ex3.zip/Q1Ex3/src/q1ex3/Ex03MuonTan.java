/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package q1ex3;

/**
 *
 * @author MUON
 */
public class Ex03MuonTan {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Wallet myWallet = new Wallet("Rattan", 25.25f);
        Wallet yourWallet = new Wallet("Leather", 5000.00f);
        Wallet theirWallet = new Wallet("Aluminum", 10000.80f);
        Song aiaiaia = new Song("aiaiaia", "country", 300);
        Song clearestSight = new Song("Clearest Sight","rock", 900);
        Singer normalAlYankovic = new Singer("Normal Al Yankovic");
        normalAlYankovic.changeFavSong(aiaiaia);
        normalAlYankovic.performForAudience(12);
        normalAlYankovic.changeFavSong(clearestSight);
        
    }
    
}
