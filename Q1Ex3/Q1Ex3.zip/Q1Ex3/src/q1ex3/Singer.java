/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package q1ex3;

/**
 *
 * @author MUON
 */
public class Singer {
    String name;
    int noOfPerformances;
    double earnings;
    Song favSong;
    
    public Singer(String name){
        this.name = name;
        this.noOfPerformances = 0;
        this.earnings = 0;    
    }
    public void performForAudience(int noOfPeople){
        this.noOfPerformances++;
        this.earnings += noOfPeople*5;
    }
    public void changeFavSong(Song favSong){
        this.favSong = favSong;
    }
}
