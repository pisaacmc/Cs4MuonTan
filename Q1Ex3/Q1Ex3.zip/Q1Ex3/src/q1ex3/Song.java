/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package q1ex3;

/**
 *
 * @author MUON
 */
public class Song {
    String name;
    String genre;
    int secondsLength;
    int timesSung;
    String playlists[];
    
    public Song(String name, String genre, int secondsLength){
        this.name = name;
        this.genre = genre;
        this.secondsLength = secondsLength;
        this.timesSung = 0;
    }
  
    
}
