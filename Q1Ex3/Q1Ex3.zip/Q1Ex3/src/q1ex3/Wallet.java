/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package q1ex3;

/**
 *
 * @author MUON
 */
public class Wallet {
    float money;
    String cover;
    public Wallet(String cover, float money){
        this.money = money;
        this.cover = cover;
    }
    public void spend(float amount){
        this.money -= amount;
    }
}
